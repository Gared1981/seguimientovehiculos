import argparse
import getpass
import os
from app import create_app, db
from app.models import User, Role
from werkzeug.security import generate_password_hash

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=5000, type=int)
    parser.add_argument("command", nargs="?", default="run", choices=["run","db_init"])
    args = parser.parse_args()

    app = create_app()
    with app.app_context():
        if args.command == "db_init":
            db.create_all()
            # Create default roles
            if not Role.query.filter_by(name="admin").first():
                db.session.add(Role(name="admin"))
            if not Role.query.filter_by(name="driver").first():
                db.session.add(Role(name="driver"))
            db.session.commit()

            email = input("Email del admin: ").strip().lower()
            name  = input("Nombre del admin: ").strip()
            pwd   = getpass.getpass("Password del admin: ")
            if User.query.filter_by(email=email).first():
                print("Usuario ya existe.")
            else:
                admin_role = Role.query.filter_by(name="admin").first()
                u = User(email=email, name=name, password_hash=generate_password_hash(pwd))
                u.roles.append(admin_role)
                db.session.add(u)
                db.session.commit()
                print("Usuario admin creado.")
            return
    app.run(host=args.host, port=args.port, debug=False)

if __name__ == "__main__":
    main()
