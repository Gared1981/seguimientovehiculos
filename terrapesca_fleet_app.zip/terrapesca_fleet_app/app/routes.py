from datetime import datetime, timedelta, date
import io, csv
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_from_directory, send_file, current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from . import db
from .models import User, Role, Vehicle, VehiclePhoto, Regulation, TripLog, TripPhoto, RepairDoc
from .forms import LoginForm, VehicleForm, RegulationForm, TripOutForm, TripInForm, SanctionForm
from .utils import save_files
import os

bp = Blueprint("core", __name__)

@bp.app_context_processor
def inject_roles():
    def has_role(user, role):
        return user and user.has_role(role)
    return dict(has_role=has_role)

@bp.route("/uploads/<path:filename>")
@login_required
def uploads(filename):
    # Serve uploaded files
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename, as_attachment=False)

@bp.route("/", methods=["GET"])
@login_required
def index():
    # Dashboard: alerts + quick actions differ by role
    alerts = compute_alerts()
    recent_trips = TripLog.query.order_by(TripLog.id.desc()).limit(10).all()
    return render_template("index.html", alerts=alerts, recent_trips=recent_trips)

@bp.route("/login", methods=["GET","POST"])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower()).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            if not user.accepted_regulation_at:
                # force review/accept regulation before proceeding
                return redirect(url_for("core.regulation"))
            return redirect(url_for("core.index"))
        flash("Credenciales inválidas", "danger")
    return render_template("login.html", form=form)

@bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("core.login"))

# Regulations
@bp.route("/regulation", methods=["GET","POST"])
@login_required
def regulation():
    reg = Regulation.query.first()
    if request.method == "POST":
        # accept terms
        current_user.accepted_regulation_at = datetime.utcnow()
        db.session.commit()
        return redirect(url_for("core.index"))
    return render_template("regulation.html", regulation=reg)

@bp.route("/admin/regulation_edit", methods=["GET","POST"])
@login_required
def regulation_edit():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    reg = Regulation.query.first()
    form = RegulationForm(obj=reg)
    if form.validate_on_submit():
        if not reg:
            reg = Regulation(content=form.content.data)
            db.session.add(reg)
        else:
            reg.content = form.content.data
        db.session.commit()
        flash("Reglamento actualizado", "success")
        return redirect(url_for("core.regulation"))
    return render_template("regulation_edit.html", form=form)

# Vehicles
@bp.route("/admin/vehicles")
@login_required
def vehicles():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    items = Vehicle.query.order_by(Vehicle.id.desc()).all()
    return render_template("vehicles.html", items=items)

@bp.route("/admin/vehicle/new", methods=["GET","POST"])
@login_required
def vehicle_new():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    form = VehicleForm()
    if form.validate_on_submit():
        v = Vehicle(
            plates=form.plates.data.strip().upper(),
            brand=form.brand.data.strip(),
            model=form.model.data.strip(),
            year=form.year.data,
            color=form.color.data.strip(),
            vin=form.vin.data.strip() if form.vin.data else None,
            current_km=form.current_km.data,
            last_service_km=form.last_service_km.data or 0,
            last_service_date=form.last_service_date.data,
            insurance_expiry=form.insurance_expiry.data
        )
        db.session.add(v)
        db.session.commit()
        flash("Vehículo creado", "success")
        return redirect(url_for("core.vehicles"))
    return render_template("vehicle_form.html", form=form, title="Nuevo vehículo")

@bp.route("/admin/vehicle/<int:vid>/edit", methods=["GET","POST"])
@login_required
def vehicle_edit(vid):
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    v = Vehicle.query.get_or_404(vid)
    form = VehicleForm(obj=v)
    if form.validate_on_submit():
        v.plates=form.plates.data.strip().upper()
        v.brand=form.brand.data.strip()
        v.model=form.model.data.strip()
        v.year=form.year.data
        v.color=form.color.data.strip()
        v.vin=form.vin.data.strip() if form.vin.data else None
        v.current_km=form.current_km.data
        v.last_service_km=form.last_service_km.data or 0
        v.last_service_date=form.last_service_date.data
        v.insurance_expiry=form.insurance_expiry.data
        db.session.commit()
        flash("Vehículo actualizado", "success")
        return redirect(url_for("core.vehicles"))
    return render_template("vehicle_form.html", form=form, title=f"Editar {v.plates}")

@bp.route("/admin/vehicle/<int:vid>/photos", methods=["POST"])
@login_required
def vehicle_photos(vid):
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    v = Vehicle.query.get_or_404(vid)
    files = request.files.getlist("photos")
    saved = save_files(files, "vehicle_photos")
    for p in saved:
        db.session.add(VehiclePhoto(vehicle_id=v.id, path=p))
    db.session.commit()
    flash(f"{len(saved)} foto(s) cargadas", "success")
    return redirect(url_for("core.vehicles"))

# Trip logs
@bp.route("/trip/out", methods=["GET","POST"])
@login_required
def trip_out():
    form = TripOutForm()
    form.vehicle_id.choices = [(v.id, f"{v.plates} - {v.brand} {v.model}") for v in Vehicle.query.order_by(Vehicle.plates).all()]
    if form.validate_on_submit():
        t = TripLog(
            vehicle_id=form.vehicle_id.data,
            driver_id=current_user.id,
            out_time=datetime.utcnow(),
            out_km=form.out_km.data,
            status="open"
        )
        db.session.add(t)
        db.session.commit()
        files = request.files.getlist("out_photos")
        saved = save_files(files, "trip_photos")
        for p in saved:
            db.session.add(TripPhoto(trip_id=t.id, phase="out", path=p))
        db.session.commit()
        flash("Salida registrada", "success")
        return redirect(url_for("core.trip_detail", tid=t.id))
    return render_template("trip_out.html", form=form)

@bp.route("/trip/<int:tid>", methods=["GET"])
@login_required
def trip_detail(tid):
    t = TripLog.query.get_or_404(tid)
    return render_template("trip_detail.html", t=t)

@bp.route("/trip/<int:tid>/in", methods=["GET","POST"])
@login_required
def trip_in(tid):
    t = TripLog.query.get_or_404(tid)
    if t.status != "open":
        flash("Este viaje ya fue cerrado", "warning")
        return redirect(url_for("core.trip_detail", tid=t.id))
    form = TripInForm()
    if form.validate_on_submit():
        t.in_time = datetime.utcnow()
        t.in_km = form.in_km.data
        t.cleaned = form.cleaned.data
        t.fluids_checked = form.fluids_checked.data
        t.notes = form.notes.data
        t.status = "returned"
        # Save photos
        files = request.files.getlist("in_photos")
        saved = save_files(files, "trip_photos")
        for p in saved:
            db.session.add(TripPhoto(trip_id=t.id, phase="in", path=p))
        # Update vehicle km
        v = t.vehicle
        if t.in_km and t.in_km > v.current_km:
            v.current_km = t.in_km
        # Basic damage heuristic
        if t.in_km is not None and t.in_km < t.out_km:
            t.damage_flag = True
        db.session.commit()
        flash("Devolución registrada", "success")
        return redirect(url_for("core.trip_detail", tid=t.id))
    return render_template("trip_in.html", form=form, t=t)

@bp.route("/admin/trip/<int:tid>/sanction", methods=["GET","POST"])
@login_required
def trip_sanction(tid):
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    t = TripLog.query.get_or_404(tid)
    form = SanctionForm(obj=t)
    if form.validate_on_submit():
        t.sanction = form.sanction.data if form.sanction.data else None
        t.damage_flag = form.damage_flag.data
        # files
        files = request.files.getlist("repair_docs")
        saved = save_files(files, "trip_photos")
        for p in saved:
            db.session.add(RepairDoc(trip_id=t.id, doc_type="adjunto", path=p))
        if t.sanction or t.damage_flag:
            t.status = "sanctioned"
        db.session.commit()
        flash("Sanción/adjuntos aplicados", "success")
        return redirect(url_for("core.trip_detail", tid=t.id))
    return render_template("trip_sanction.html", form=form, t=t)

# History & export
@bp.route("/admin/history")
@login_required
def history():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    q = TripLog.query.order_by(TripLog.id.desc()).all()
    return render_template("history.html", trips=q)

@bp.route("/admin/export_csv")
@login_required
def export_csv():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning")
        return redirect(url_for("core.index"))
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID","Vehículo","Conductor","Salida","KmOut","Regreso","KmIn","Estatus","Sanción","Daño","Notas"])
    for t in TripLog.query.order_by(TripLog.id).all():
        writer.writerow([
            t.id,
            f"{t.vehicle.plates}",
            t.driver.email,
            t.out_time.isoformat(sep=' ', timespec='minutes') if t.out_time else "",
            t.out_km or "",
            t.in_time.isoformat(sep=' ', timespec='minutes') if t.in_time else "",
            t.in_km or "",
            t.status,
            t.sanction or "",
            "Sí" if t.damage_flag else "No",
            (t.notes or "").replace("\n"," ").strip()
        ])
    mem = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    return send_file(mem, mimetype="text/csv", as_attachment=True, download_name="bitacora.csv")

def compute_alerts():
    alerts = []
    # service alert: > 8,000 km since last service OR > 6 months
    for v in Vehicle.query.all():
        due_km = (v.current_km or 0) - (v.last_service_km or 0)
        months_since = None
        if v.last_service_date:
            months_since = (date.today().year - v.last_service_date.year) * 12 + (date.today().month - v.last_service_date.month)
        if due_km is not None and due_km > 8000:
            alerts.append(dict(type="warning", msg=f"Servicio por km para {v.plates}: {due_km:,} km desde el último servicio."))
        if months_since is not None and months_since > 6:
            alerts.append(dict(type="warning", msg=f"Servicio por tiempo para {v.plates}: {months_since} meses desde el último servicio."))
        # insurance expiry in <=30 days
        if v.insurance_expiry:
            days_left = (v.insurance_expiry - date.today()).days
            if days_left <= 30:
                alerts.append(dict(type="danger", msg=f"Seguro de {v.plates} vence en {days_left} día(s)."))
    return alerts

# Lists
@bp.route("/admin/users")
@login_required
def users():
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning"); return redirect(url_for("core.index"))
    items = User.query.order_by(User.id).all()
    return render_template("users.html", items=items)

@bp.route("/admin/vehicles/<int:vid>")
@login_required
def vehicle_detail(vid):
    if not current_user.has_role("admin"):
        flash("Acceso restringido", "warning"); return redirect(url_for("core.index"))
    v = Vehicle.query.get_or_404(vid)
    return render_template("vehicle_detail.html", v=v)
