from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, IntegerField, BooleanField, TextAreaField, SelectField, DateField, FileField
from wtforms.validators import DataRequired, Email, Length, Optional
from wtforms.widgets import TextArea

class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Entrar")

class VehicleForm(FlaskForm):
    plates = StringField("Placas", validators=[DataRequired(), Length(max=20)])
    brand = StringField("Marca", validators=[DataRequired(), Length(max=50)])
    model = StringField("Modelo", validators=[DataRequired(), Length(max=50)])
    year = IntegerField("Año", validators=[DataRequired()])
    color = StringField("Color", validators=[DataRequired(), Length(max=30)])
    vin = StringField("NIV (opcional)", validators=[Optional(), Length(max=50)])
    current_km = IntegerField("Kilometraje actual", validators=[DataRequired()])
    last_service_km = IntegerField("Km último servicio", validators=[Optional()])
    last_service_date = DateField("Fecha último servicio", validators=[Optional()])
    insurance_expiry = DateField("Vencimiento seguro", validators=[Optional()])
    submit = SubmitField("Guardar")

class RegulationForm(FlaskForm):
    content = TextAreaField("Reglamento", validators=[DataRequired()], widget=TextArea())
    submit = SubmitField("Guardar")

class TripOutForm(FlaskForm):
    vehicle_id = SelectField("Vehículo", coerce=int, validators=[DataRequired()])
    out_km = IntegerField("Kilometraje de salida", validators=[DataRequired()])
    out_photos = FileField("Fotos de salida (puedes seleccionar múltiples)", render_kw={"multiple": True})
    submit = SubmitField("Registrar salida")

class TripInForm(FlaskForm):
    in_km = IntegerField("Kilometraje de regreso", validators=[DataRequired()])
    cleaned = BooleanField("Limpieza realizada")
    fluids_checked = BooleanField("Niveles revisados")
    notes = TextAreaField("Observaciones", validators=[Optional()])
    in_photos = FileField("Fotos de regreso (puedes seleccionar múltiples)", render_kw={"multiple": True})
    submit = SubmitField("Registrar devolución")

class SanctionForm(FlaskForm):
    sanction = SelectField("Sanción", choices=[("","--"),("Con costo al conductor","Con costo al conductor"),("Suspensión de privilegio","Suspensión de privilegio")])
    damage_flag = BooleanField("Daño/irregularidad confirmada")
    repair_docs = FileField("Adjuntar docs de reparación (múltiples)", render_kw={"multiple": True})
    submit = SubmitField("Aplicar")
