import os
import uuid
from flask import current_app

def save_files(file_storage_list, subfolder):
    saved_paths = []
    if not file_storage_list:
        return saved_paths
    upload_dir = os.path.join(current_app.config["UPLOAD_FOLDER"], subfolder)
    os.makedirs(upload_dir, exist_ok=True)
    for fs in file_storage_list:
        if not fs or fs.filename == "":
            continue
        ext = os.path.splitext(fs.filename)[1].lower()
        fname = f"{uuid.uuid4().hex}{ext}"
        path = os.path.join(upload_dir, fname)
        fs.save(path)
        # store relative for serving
        saved_paths.append(f"{subfolder}/{fname}")
    return saved_paths
