from datetime import datetime, date
from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash
from . import db, login_manager

roles_users = db.Table(
    'roles_users',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id')),
    db.Column('role_id', db.Integer, db.ForeignKey('role.id'))
)

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    accepted_regulation_at = db.Column(db.DateTime, nullable=True)

    roles = db.relationship("Role", secondary=roles_users, backref="users")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def has_role(self, role_name):
        return any(r.name == role_name for r in self.roles)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Vehicle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    plates = db.Column(db.String(20), unique=True, nullable=False)
    brand = db.Column(db.String(50), nullable=False)
    model = db.Column(db.String(50), nullable=False)
    year = db.Column(db.Integer, nullable=False)
    color = db.Column(db.String(30), nullable=False)
    vin = db.Column(db.String(50), nullable=True)
    current_km = db.Column(db.Integer, default=0)
    last_service_km = db.Column(db.Integer, default=0)
    last_service_date = db.Column(db.Date, nullable=True)
    insurance_expiry = db.Column(db.Date, nullable=True)
    photos = db.relationship("VehiclePhoto", backref="vehicle", cascade="all,delete")

class VehiclePhoto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'))
    path = db.Column(db.String(255), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

class Regulation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class TripLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicle.id'), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    out_time = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    out_km = db.Column(db.Integer, nullable=False)
    in_time = db.Column(db.DateTime, nullable=True)
    in_km = db.Column(db.Integer, nullable=True)
    cleaned = db.Column(db.Boolean, default=False)
    fluids_checked = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), default="open")  # open, returned, sanctioned
    sanction = db.Column(db.String(120), nullable=True) # "Con costo al conductor" etc.
    damage_flag = db.Column(db.Boolean, default=False)

    vehicle = db.relationship("Vehicle", backref="trip_logs")
    driver  = db.relationship("User", backref="trip_logs")
    photos = db.relationship("TripPhoto", backref="trip", cascade="all,delete")
    repairs = db.relationship("RepairDoc", backref="trip", cascade="all,delete")

class TripPhoto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip_log.id'))
    phase = db.Column(db.String(10))  # 'out' or 'in'
    path = db.Column(db.String(255), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

class RepairDoc(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    trip_id = db.Column(db.Integer, db.ForeignKey('trip_log.id'))
    doc_type = db.Column(db.String(50))  # cotizacion|factura
    path = db.Column(db.String(255), nullable=False)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
