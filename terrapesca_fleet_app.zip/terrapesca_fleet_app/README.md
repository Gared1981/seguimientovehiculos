# Terrapesca Fleet Control (Flask)

Sistema interno para control de vehículos de empresa: bitácora de uso, evidencias fotográficas, responsabilidades y alertas.

## Características clave
- Usuarios y roles (Administrador, Conductor/Vendedor).
- Autenticación de usuarios.
- Registro de vehículos (con fotos).
- Reglamento interno editable y aceptación por usuario.
- Bitácora de salidas y devoluciones con fotos antes/después, km inicial/final, limpieza y observaciones.
- Marcado de daños y asignación de responsabilidad/costo.
- Adjuntar cotización/factura de reparación.
- Historial por vehículo y usuario, métricas básicas.
- Alertas por servicio y vencimiento de seguro.
- Exportación CSV.
- UI responsiva con Bootstrap 5.

## Requisitos
- Python 3.10+
- pip

## Instalación
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# (opcional) edita .env
python run.py db_init  # inicializa la base de datos y crea usuario admin
```

El script de inicialización te solicitará las credenciales del usuario administrador.

## Ejecución
```bash
python run.py
# o con host público en red local:
python run.py --host 0.0.0.0 --port 5000
```

## Estructura
- `app/models.py` Definiciones de modelos (User, Vehicle, Regulation, TripLog, RepairDoc).
- `app/forms.py` Formularios WTForms.
- `app/routes.py` Rutas y lógica del sistema.
- `app/templates/` Plantillas Jinja2 con Bootstrap 5.
- `app/static/` Recursos estáticos.
- `app/uploads/` Carpeta de archivos subidos.

## Exportar CSV
Desde el panel Admin, botón "Exportar CSV".

## Notas de seguridad
- Cambia `FLASK_SECRET_KEY` en `.env`.
- Configura un reverso proxy/HTTPS en producción.
- Revisa permisos del directorio `app/uploads`.

## Licencia
Uso interno de Terrapesca.
